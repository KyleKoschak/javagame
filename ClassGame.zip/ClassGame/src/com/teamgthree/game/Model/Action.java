
package com.teamgthree.game.Model;


/**
 * @author josh
 *
 */
public interface Action {
	void performAction(Character character);
}
