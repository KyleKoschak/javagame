package com.teamgthree.game.Model;

public enum Enemies {
	ORC, DRAGON
}
