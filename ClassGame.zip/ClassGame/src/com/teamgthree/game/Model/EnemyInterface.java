package com.teamgthree.game.Model;

public interface EnemyInterface {
	public void stats(int strength, int dexterity, int intelligence);
}
