package com.teamgthree.game.Model;

public enum Classes {
	RANGED,MELEE,CASTER,ORC,DRAGON
}
