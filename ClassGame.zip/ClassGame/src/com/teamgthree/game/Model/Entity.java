package com.teamgthree.game.Model;

public interface Entity {
	public void updateState();
	public String toString();
}
