package com.teamgthree.game.View;

public enum Direction {
	NORTH,SOUTH, EAST, WEST;
}
